CREATE DATABASE dashboard_ventas;

USE dashboard_ventas;

CREATE TABLE ventas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mes VARCHAR(20),
    total DECIMAL(10,2)
);

INSERT INTO ventas (mes, total) VALUES
('Enero', 15000),
('Febrero', 18500),
('Marzo', 14000),
('Abril', 23000),
('Mayo', 27500),
('Junio', 30500);

SELECT * FROM ventas;

