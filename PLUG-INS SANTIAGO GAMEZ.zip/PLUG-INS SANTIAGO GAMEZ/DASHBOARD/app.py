from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)


@app.route("/")
def inicio():

    conexion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root123",
        database="dashboard_ventas"
    )

    cursor = conexion.cursor()

    cursor.execute("SELECT mes, total FROM ventas")
    datos = cursor.fetchall()

    meses = []
    ventas = []

    for dato in datos:
        meses.append(dato[0])
        ventas.append(float(dato[1]))

    cursor.close()
    conexion.close()

    total_ventas = sum(ventas)
    promedio = total_ventas / len(ventas) if ventas else 0

    if ventas:
        venta_maxima = max(ventas)
        posicion = ventas.index(venta_maxima)
        mejor_mes = meses[posicion]
    else:
        mejor_mes = "Sin datos"

    return render_template(
        "index.html",
        meses=meses,
        ventas=ventas,
        total_ventas=total_ventas,
        promedio=promedio,
        mejor_mes=mejor_mes
    )


if __name__ == "__main__":
    app.run(debug=True)